package com.nt.dao;

import com.nt.bo.DepartmentBO;

public interface DepartmentDAO {
	public  int  insert(DepartmentBO bo);
	

}
