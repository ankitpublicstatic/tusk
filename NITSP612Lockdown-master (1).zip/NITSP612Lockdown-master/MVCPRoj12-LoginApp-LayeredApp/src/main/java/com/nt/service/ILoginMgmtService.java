package com.nt.service;

import com.nt.dto.UserDTO;

public interface ILoginMgmtService {
    public  String login(UserDTO dto);
}
