package com.nt.service;

import com.nt.dto.StudentDTO;

public interface StudentOperationsService {
   public String  register(StudentDTO dto)throws Exception;
}
