package com.nt.dao;

public interface DepositeDAO {
    public  int deposite(long acno,float amt);
}
