package com.nt.service;

public interface BankMgmtService {
	
	public  String withdrawMoney(int acno,float amt); 
	public  String depositeMoney(int acno,float amt); 

}
